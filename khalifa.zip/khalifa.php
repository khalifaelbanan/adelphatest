<!DOCTYPE HTML>
<html lang="FR" dir="LTR">
	<head>
		<title>Adelpha</title>
		<link rel="stylesheet" type="text/css" href="khalifa.css">
		<meta name="author" content="Khalifa EL BANAN"/>
		<meta name="made" content="khalifa.elbanan@gmail.com"/>
		<meta name="description" content="cette page est ..."/>
		<meta name="keywords" content="page, html, khalifa"/>
		<meta name="generator" content="sublime text"/>
		<meta name="robots" content="noindex, nofollow">
		<meta http-equiv="content type" content="text/html; charset=UTF-8"/>
	<head>
	<body link="red" alink="red" vlink="red">
		<h1>Soufiane</h1>
		<?php 
			echo "version 6<br/>";
			echo "Adelpha AWS";
		?>
	</body>

</html>
